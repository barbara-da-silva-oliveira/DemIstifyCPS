
```
 * JGraphT version:
 * Java version (java -version)/platform:  
```

**Issue**



**Steps to reproduce (small coding example)**



**Expected behaviour**



**Other information**
