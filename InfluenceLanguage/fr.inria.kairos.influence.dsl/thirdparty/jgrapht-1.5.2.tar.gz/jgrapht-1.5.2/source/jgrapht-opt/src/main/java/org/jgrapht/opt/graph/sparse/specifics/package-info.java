/**
 * Implementations of different sparse graphs with different tradeoffs.
 */
package org.jgrapht.opt.graph.sparse.specifics;
